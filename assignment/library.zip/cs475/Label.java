package cs475;

import java.io.Serializable;

public abstract class Label implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8700608400812094513L;

	public abstract String toString();
}
